"""唱歌插件：说「唱 歌名」→ 按后台开关决定发什么 → 跑 Seed-VC 流水线 → 发送。

三个开关（后台可各自开关）：
  allow_voice  多条语音（超过单条上限自动均分）
  allow_video  一条视频（封面 + 音频，一条消息听完）
  allow_file   直接发 mp3

只开一个 → 不询问；开两个及以上 → 每次问一句「怎么发」。

运行环境（venv / Seed-VC / ffmpeg 的路径）由插件目录下的 runtime.json 提供，
那个文件由同包的 install.ps1 生成。
"""

import asyncio
import time
import traceback
from pathlib import Path

from astrbot.api import logger
from astrbot.api.event import AstrMessageEvent, filter
from astrbot.api.message_components import File, Image, Record, Video
from astrbot.api.star import Context, Star, register

from .core import bili_login, pipeline

PLUGIN_DIR = Path(__file__).parent
DEFAULT_TRIGGERS = ["唱歌", "唱"]
DEFAULT_OWNERS: list[str] = []  # 在插件设置里填自己的 QQ
PENDING_TTL = 180

MODE_META = {
    "voice": {"label": "多条语音", "words": ("语音", "语音条", "多条语音", "voice")},
    "video": {"label": "一条视频", "words": ("视频", "video")},
    "file": {"label": "mp3 文件", "words": ("文件", "mp3", "file")},
}
MODE_ORDER = ("voice", "video", "file")

PLAY_WORDS = ("点歌", "听歌", "放歌")
LOGIN_WORDS = {"B站登录", "b站登录", "bili登录", "B站扫码登录", "扫码登录"}
STATUS_WORDS = {"B站状态", "b站状态", "刷新状态", "B站刷新状态"}
RELOGIN_WORDS = {"重新登录", "重登", "B站重新登录"}


def _clean_list(value) -> list[str]:
    if not value:
        return []
    if isinstance(value, str):
        value = [value]
    return [str(v).strip() for v in value if str(v).strip()]


@register("sing", "local", "用她的声音翻唱：唱 歌名", "v0.4.0")
class SingPlugin(Star):
    def __init__(self, context: Context, config=None) -> None:
        super().__init__(context)
        self.conf = config
        self.runtime = pipeline.load_runtime(PLUGIN_DIR)
        self._lock = asyncio.Lock()
        self._pending: dict[tuple[str, str], dict] = {}
        self._recent_reply: dict[tuple[str, str], tuple[str, float]] = {}
        if not self.runtime:
            logger.warning("[唱歌] 没找到 runtime.json，先运行 install.ps1 或在插件设置里填路径")
        if not bool(self._cfg("need_wake", True)):
            self._install_wake_patch()

    # ---------- 不需要唤醒词时，自己把消息"点亮" ----------
    def _install_wake_patch(self) -> None:
        """need_wake=false 时，群里只要以触发词开头，就算叫到她（不用 @、不用唤醒词）。

        唤醒判定在插件之前发生，没被唤醒的消息会被直接丢弃，插件根本看不到，
        所以这里给 WakingCheckStage 包一层：原逻辑跑完后补一个唤醒状态。
        """
        try:
            import inspect
            from collections.abc import AsyncGenerator

            from astrbot.core.platform.message_type import MessageType
            from astrbot.core.pipeline.waking_check.stage import WakingCheckStage
        except Exception as e:
            logger.warning(f"[唱歌] 免唤醒补丁跳过（导入失败）：{e}")
            return

        if getattr(WakingCheckStage, "_sing_wake_patched", False):
            return

        original = WakingCheckStage.process
        plugin = self

        async def patched(stage_self, event):
            result = original(stage_self, event)
            if inspect.isasyncgen(result) or isinstance(result, AsyncGenerator):
                async for _ in result:
                    yield
            else:
                await result
                yield
            try:
                if bool(plugin._cfg("need_wake", True)):
                    return
                if event.get_message_type() != MessageType.GROUP_MESSAGE:
                    return
                if getattr(event, "is_at_or_wake_command", False):
                    return
                text = (event.message_str or "").strip().lstrip("，,。.！!？?、~～～…—：:;； \t\u3000")
                triggers = plugin._triggers()
                admins = _clean_list(plugin._cfg("admin_uins", DEFAULT_OWNERS))
                is_admin = str(event.get_sender_id()) in admins
                hit = (
                    any(w in text for w in triggers)
                    if is_admin
                    else (not bool(plugin._cfg("need_wake", True)) and any(text.startswith(w) for w in triggers))
                )
                if not hit:
                    return
                event.is_at_or_wake_command = True
                event.is_wake = True
                event.continue_event()
                logger.info(f"[唱歌] 免唤醒命中：{text[:20]}")
            except Exception as e:
                logger.warning(f"[唱歌] 免唤醒处理异常：{e}")

        WakingCheckStage.process = patched
        WakingCheckStage._sing_wake_patched = True
        logger.info("[唱歌] 已开启免唤醒模式（触发词直接生效）")

    def _cfg(self, key, default):
        try:
            if self.conf is None:
                return default
            return self.conf.get(key, default)
        except Exception:
            return default

    def _run_cfg(self) -> dict:
        """路径来自 runtime.json，行为参数来自插件配置。"""
        cfg = dict(self.runtime)
        cfg["ref_audio"] = self._cfg("ref_audio", "") or cfg.get("ref_audio", "")
        cfg["clip_start"] = int(self._cfg("clip_start", 0))
        cfg["clip_seconds"] = int(self._cfg("clip_seconds", 420))
        cfg["diffusion_steps"] = int(self._cfg("diffusion_steps", 60))
        cfg["cfg_rate"] = float(self._cfg("cfg_rate", 0))
        cfg["semi_tone_shift"] = int(self._cfg("semi_tone_shift", 0))
        cfg["enable_bilibili"] = bool(self._cfg("enable_bilibili", True))
        cfg["bili_cookie"] = bili_login.load_cookies(PLUGIN_DIR)
        return cfg

    def _enabled_modes(self) -> list[str]:
        flags = {
            "voice": bool(self._cfg("allow_voice", True)),
            "video": bool(self._cfg("allow_video", True)),
            "file": bool(self._cfg("allow_file", True)),
        }
        return [m for m in MODE_ORDER if flags[m]]

    @staticmethod
    def _clean(raw: str) -> str:
        return (raw or "").strip().lstrip("，,。.！!？?、~～…—：:;； \t\u3000")

    def _triggers(self) -> list[str]:
        words = _clean_list(self._cfg("trigger_words", DEFAULT_TRIGGERS)) or DEFAULT_TRIGGERS
        # 长的排前面，避免「唱」把「唱歌」吃掉
        return sorted(words, key=len, reverse=True)

    def _parse_title(self, raw: str) -> str:
        t = raw.strip()
        for w in self._triggers():
            if t.startswith(w):
                t = t[len(w):].strip(" ：:，,、")
                break
        return t.strip()

    @staticmethod
    def _match_mode(raw: str, options: list[str]) -> str | None:
        token = raw.strip().lower()
        if token.isdigit():
            idx = int(token) - 1
            return options[idx] if 0 <= idx < len(options) else None
        for mode in options:
            if token in MODE_META[mode]["words"]:
                return mode
        return None

    def _ask_text(self, title: str, options: list[str]) -> str:
        marks = "①②③④"
        parts = [f"{marks[i]}{MODE_META[m]['label']}" for i, m in enumerate(options)]
        nums = " / ".join(str(i + 1) for i in range(len(options)))
        return f"{title}。怎么发？回我 {nums}（等待 3 秒再选择）\n" + "　".join(parts)

    # ---------- 待回复状态（选版本 / 选发送方式） ----------
    def _set_pending(self, key, kind: str, **kw) -> None:
        kw["kind"] = kind
        kw["ts"] = time.time()
        self._pending[key] = kw

    def _get_pending(self, key):
        item = self._pending.get(key)
        if not item:
            return None
        if time.time() - item.get("ts", 0) > PENDING_TTL:
            self._pending.pop(key, None)
            return None
        return item

    @filter.event_message_type(filter.EventMessageType.ALL, priority=2000)
    async def on_message(self, event: AstrMessageEvent):
        if not bool(self._cfg("enable", True)):
            return

        umo = event.unified_msg_origin
        sender = str(event.get_sender_id())
        key = (umo, sender)
        raw = self._clean(event.message_str)

        # ---- 点歌：和翻唱同一套「选源 → 选版本」流程 ----
        if any(raw.startswith(w) for w in PLAY_WORDS):
            if not bool(self._cfg("play_enabled", True)):
                event.should_call_llm(True)
                yield event.plain_result("点歌功能关掉了。要听她唱就说「唱 歌名」")
                return
            title = raw
            for w in PLAY_WORDS:
                if title.startswith(w):
                    title = title[len(w):].strip(" ：:，,、")
                    break
            event.should_call_llm(True)
            owners = _clean_list(self._cfg("owner_uins", DEFAULT_OWNERS))
            admins = _clean_list(self._cfg("admin_uins", DEFAULT_OWNERS))
            is_owner = sender in owners or sender in admins
            if (not is_owner) and not bool(self._cfg("others_enabled", True)):
                yield event.plain_result("点歌只对主人开放")
                return
            if not title:
                yield event.plain_result("点什么歌？说「点歌 歌名」")
                return
            async for r in self._begin(event, key, title, action="play"):
                yield r
            return

        # ---- B 站扫码登录 / 状态 ----
        if raw in LOGIN_WORDS or raw in RELOGIN_WORDS:
            admins = _clean_list(self._cfg("admin_uins", DEFAULT_OWNERS))
            if sender not in admins:
                event.should_call_llm(True)
                yield event.plain_result("只有管理员能登 B 站账号")
                return
            event.should_call_llm(True)
            if raw in LOGIN_WORDS:
                ok, label = await self._bili_login_state()
                if ok:
                    yield event.plain_result(f"已经登录了：{label}，不用再扫（想换号发「重新登录」）")
                    return
            if raw in RELOGIN_WORDS:
                (PLUGIN_DIR / "bili_cookies.json").unlink(missing_ok=True)
                yield event.plain_result("旧登录已清掉，重新扫")
            async for r in self._bili_login(event):
                yield r
            return
        if raw in STATUS_WORDS:
            event.should_call_llm(True)
            yield event.plain_result(await self._bili_status())
            return

        # ---- 正在等回复：选版本 或 选发送方式 ----
        pending = self._get_pending(key)
        if pending and raw:
            last = self._recent_reply.get(key)
            if last and last[0] == raw and time.time() - last[1] < 3:
                return  # 同一条回复被投递了两次，忽略后一次
            self._recent_reply[key] = (raw, time.time())

            if raw in ("取消", "不唱了", "算了"):
                self._pending.pop(key, None)
                event.should_call_llm(True)
                yield event.plain_result("行，不唱了")
                return

            if pending["kind"] == "source":
                src_opt = self._match_source(raw, pending["sources"])
                if src_opt:
                    self._pending.pop(key, None)
                    event.should_call_llm(True)
                    async for r in self._begin(event, key, pending["title"], source=src_opt, action=pending.get("action", "cover")):
                        yield r
                    return
            elif pending["kind"] == "version":
                songs = pending["songs"]
                if raw.isdigit() and 1 <= int(raw) <= len(songs):
                    chosen = songs[int(raw) - 1]
                    self._pending.pop(key, None)
                    event.should_call_llm(True)
                    title2 = f"{chosen['name']} {chosen['artists']}".strip()
                    async for r in self._begin(event, key, title2, preferred=chosen, action=pending.get("action", "cover")):
                        yield r
                    return
            elif pending["kind"] == "mode":
                mode = self._match_mode(raw, pending["options"])
                if mode:
                    self._pending.pop(key, None)
                    event.should_call_llm(True)
                    async for r in self._run(event, pending["title"], mode, pending.get("preferred"), pending.get("source")):
                        yield r
                    return

        if not getattr(event, "is_at_or_wake_command", False):
            return
        admins = _clean_list(self._cfg("admin_uins", DEFAULT_OWNERS))
        is_admin = sender in admins
        triggers = self._triggers()
        if is_admin:
            if not any(w in raw for w in triggers):
                return
            cut_at = min(raw.index(w) for w in triggers if w in raw)
            raw = raw[cut_at:]
        elif not any(raw.startswith(w) for w in triggers):
            return
        title = self._parse_title(raw)
        if title.startswith(("一首", "首歌")):
            return

        event.should_call_llm(True)

        owners = _clean_list(self._cfg("owner_uins", DEFAULT_OWNERS))
        is_owner = sender in owners or is_admin
        if not is_admin and is_owner and not bool(self._cfg("owner_enabled", True)):
            yield event.plain_result("唱歌这个功能主人自己关掉了")
            return
        if (not is_owner) and (not is_admin) and not bool(self._cfg("others_enabled", True)):
            yield event.plain_result("唱歌只对主人开放，你先去听她说话吧")
            return

        if not title:
            yield event.plain_result("唱什么？说「唱 歌名」")
            return
        if self._lock.locked():
            yield event.plain_result("上一首还在录，等我唱完这首")
            return

        async for r in self._begin(event, key, title):
            yield r

    def _enabled_sources(self) -> list[str]:
        out = []
        if bool(self._cfg("enable_netease", True)):
            out.append("netease")
        if bool(self._cfg("enable_bilibili", True)):
            out.append("bili")
        return out

    @staticmethod
    def _match_source(raw: str, options: list[str]) -> str | None:
        token = raw.strip().lower()
        names = {"netease": ("网易云", "网易", "netease", "1"), "bili": ("b站", "bili", "哔哩", "2")}
        for opt in options:
            if token in names.get(opt, ()) or token == str(options.index(opt) + 1):
                return opt
        return None

    async def _begin(self, event: AstrMessageEvent, key, title: str, preferred: dict | None = None,
                     source: str | None = None, action: str = "cover"):
        """确定歌之后：选源 → 选版本 →（翻唱还要选发送方式 / 点歌直接放）。"""
        if action == "cover":
            options = self._enabled_modes()
            if not options:
                yield event.plain_result("后台三个发送方式都关着，先在插件设置里打开一个")
                return

        # 1) 选源
        if preferred is None and source is None:
            sources = self._enabled_sources()
            if not sources:
                yield event.plain_result("后台两个音源都关着，先打开一个")
                return
            if len(sources) > 1:
                self._set_pending(key, "source", title=title, sources=sources, action=action)
                yield event.plain_result("用哪个源？回 1 或 2（等待 3 秒再选择）\n① 网易云　② B 站")
                return
            source = sources[0]

        # 2) 选版本
        if preferred is None and bool(self._cfg("ask_version", True)):
            try:
                _key, _hint, songs = await asyncio.to_thread(
                    pipeline.list_versions, title, 6, self._run_cfg(), source or "all"
                )
            except Exception:
                songs = []
            if len(songs) > 1:
                self._set_pending(key, "version", title=title, songs=songs, source=source, action=action)
                lines = []
                for i, s in enumerate(songs, 1):
                    sec = int(s.get("actual_seconds") or (s.get("duration") or 0) / 1000)
                    mark = "①②③④⑤⑥⑦⑧⑨"[i - 1] if i <= 9 else f"{i}."
                    if s.get("source") == "bili":
                        tag = " ［B站］"
                    elif s.get("trial"):
                        tag = " ［仅试听］"
                    else:
                        tag = " ［可听全］"
                    nm = s["name"] if len(s["name"]) <= 18 else s["name"][:18] + "…"
                    ar = s["artists"] if len(s["artists"] or "") <= 10 else (s["artists"] or "")[:10] + "…"
                    lines.append(f"{mark} {nm} - {ar}{tag}（{sec // 60}:{sec % 60:02d}）")
                yield event.plain_result("找到多个版本，回数字选一个（等待 3 秒再选择）：" + "　".join(lines))
                return
            if not songs:
                yield event.plain_result(f"{title}：这个源没搜到可用的版本")

        # 3) 点歌：直接放原曲
        if action == "play":
            async for r in self._play(event, title, preferred, source):
                yield r
            return

        # 4) 翻唱：选发送方式
        options = self._enabled_modes()
        words = title.split()
        if len(words) >= 2:
            suffix = words[-1].lower()
            for mode in options:
                if suffix in MODE_META[mode]["words"]:
                    async for r in self._run(event, " ".join(words[:-1]), mode, preferred, source):
                        yield r
                    return

        if len(options) == 1:
            async for r in self._run(event, title, options[0], preferred, source):
                yield r
            return

        self._set_pending(key, "mode", title=title, options=options, preferred=preferred, source=source)
        yield event.plain_result(self._ask_text(title, options))

    async def _play(self, event: AstrMessageEvent, title: str, preferred: dict | None = None,
                    source: str | None = None):
        if self._lock.locked():
            yield event.plain_result("正在录歌，等这首唱完")
            return
        async with self._lock:
            yield event.plain_result(f"{title}，找一下")
            try:
                run_cfg = self._run_cfg()
                if preferred:
                    run_cfg["preferred"] = preferred
                if source:
                    run_cfg["force_source"] = source
                info = await asyncio.to_thread(pipeline.fetch_original, title, run_cfg, None, preferred)
            except Exception as e:
                logger.error(f"[点歌] 失败：{e}\n{traceback.format_exc()}")
                yield event.plain_result(f"没找到：{e}")
                return

        path = Path(info["path"])
        name = f"{info['name']}-{info['artists']}"
        logger.info(f"[点歌] {name} {info['seconds']:.0f}s -> {path}")
        if info["seconds"] <= 120:
            yield event.chain_result([Record(file=str(path))])
        else:
            yield event.chain_result([File(name=f"{name}.mp3", file=str(path))])
        yield event.plain_result(f"《{info['name']}》{info['seconds'] / 60:.1f} 分钟")

    async def _run(self, event: AstrMessageEvent, title: str, mode: str, preferred: dict | None = None, source: str | None = None):
        if self._lock.locked():
            yield event.plain_result("上一首还在录，等我唱完这首")
            return

        label = MODE_META[mode]["label"]
        async with self._lock:
            yield event.plain_result(f"行，{title}，我唱一段（{label}），最长七分钟")
            try:
                run_cfg = self._run_cfg()
                if preferred:
                    run_cfg["preferred"] = preferred
                if source:
                    run_cfg["force_source"] = source
                result = await asyncio.to_thread(pipeline.make_cover, title, run_cfg)
            except Exception as e:
                logger.error(f"[唱歌] 失败：{e}\n{traceback.format_exc()}")
                yield event.plain_result(f"没唱成：{e}")
                return

        path = Path(result["path"])
        name = f"{result['name']}-{result['artists']}"
        logger.info(f"[唱歌] 完成：{name} {result['seconds']:.1f}s mode={mode} -> {path}")

        try:
            if mode == "voice":
                async for r in self._send_voice(event, path, result):
                    yield r
            elif mode == "video":
                async for r in self._send_video(event, path, result):
                    yield r
            else:
                yield event.chain_result([File(name=f"{name}.mp3", file=str(path))])
                yield event.plain_result(f"《{result['name']}》{result['seconds']:.0f} 秒，唱完了")
        except Exception as e:
            logger.error(f"[唱歌] 发送失败：{e}\n{traceback.format_exc()}")
            yield event.plain_result(f"唱好了但没发出去：{e}")

    async def _send_voice(self, event: AstrMessageEvent, path: Path, result: dict):
        parts = [path]
        chunk = int(self._cfg("chunk_seconds", 120))
        if result["seconds"] > chunk:
            parts = await asyncio.to_thread(
                pipeline.split_audio,
                path,
                chunk,
                self.runtime["ffmpeg"],
                path.parent / "parts",
            )
        for i, part in enumerate(parts):
            if i:
                await asyncio.sleep(1.2)
            yield event.chain_result([Record(file=str(part))])
        if len(parts) > 1:
            yield event.plain_result(f"《{result['name']}》{result['seconds']:.0f} 秒，分 {len(parts)} 条发")

    async def _bili_login(self, event: AstrMessageEvent):
        """出二维码 → 轮询 → 存 Cookie。全程不经过模型。"""
        try:
            qr_path = PLUGIN_DIR / "bili_qr.png"
            key, _ = bili_login.make_qr(qr_path)
        except Exception as e:
            yield event.plain_result(f"申请二维码失败：{e}")
            return

        yield event.chain_result([Image(file=str(qr_path))])
        yield event.plain_result("用 B 站 App 扫码（我的 → 扫一扫），两分钟内有效")

        deadline = time.time() + 120
        last = ""
        while time.time() < deadline:
            await asyncio.sleep(2)
            try:
                info = bili_login.poll_once(key)
            except Exception:
                continue
            status = info["status"]
            if status == "ok":
                bili_login.save_cookies(PLUGIN_DIR, info["cookies"])
                yield event.plain_result("登录成功，B 站音源会用这个账号")
                return
            if status == "expired":
                yield event.plain_result("二维码过期了，再发一次「B站登录」")
                return
            if status == "scanned" and last != "scanned":
                last = "scanned"
                yield event.plain_result("扫到了，手机上点一下确认")
        yield event.plain_result("等太久了，没登成，再发一次「B站登录」")

    async def _bili_login_state(self) -> tuple[bool, str]:
        """返回 (是否已登录, 说明文字)。"""
        cookies = bili_login.load_cookies(PLUGIN_DIR)
        if not cookies:
            return False, "还没登录"
        try:
            import requests as _rq

            r = _rq.get(
                "https://api.bilibili.com/x/web-interface/nav",
                headers={"User-Agent": "Mozilla/5.0", "Referer": "https://www.bilibili.com/"},
                cookies=cookies,
                timeout=15,
            )
            js = r.json()
            data = js.get("data") or {}
            if js.get("code") == 0 and data.get("isLogin"):
                return True, f"{data.get('uname')}（UID {data.get('mid')}）"
            return False, "Cookie 已失效"
        except Exception as e:
            return False, f"查状态失败：{e}"

    async def _bili_status(self) -> str:
        ok, label = await self._bili_login_state()
        if ok:
            return f"B 站已登录：{label}"
        if label == "还没登录":
            return "还没登录 B 站（发「扫码登录」扫一次）"
        return f"{label}，发「重新登录」重扫"

    async def _send_video(self, event: AstrMessageEvent, path: Path, result: dict):
        cover = Path(result["cover"]) if result.get("cover") else None
        out = path.parent / "final.mp4"
        await asyncio.to_thread(pipeline.make_video, path, cover, out, self.runtime["ffmpeg"])
        yield event.chain_result([Video(file=str(out))])
        yield event.plain_result(f"《{result['name']}》{result['seconds']:.0f} 秒，一整条在这儿")
