# -*- coding: utf-8 -*-
"""唱歌流水线：搜歌 → 下载 → 截 1 分钟 → 人声分离 → 音色转换 → 混音。

这个模块不依赖 astrbot 和 torch，可以单独跑（用 svc-env 的 python 或 astrbot 自带的都行，
因为它把重活都交给子进程：demucs 和 seed-vc 的 inference.py）。
"""
from __future__ import annotations

import os
import re
import shutil
import subprocess
import tempfile
from pathlib import Path

import requests

UA = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    "Referer": "https://music.163.com/",
}

RUNTIME_FILE = "runtime.json"


def load_runtime(plugin_dir: Path) -> dict:
    """读取插件目录下的 runtime.json（install.ps1 生成），只取路径类配置。"""
    import json

    path = Path(plugin_dir) / RUNTIME_FILE
    data = {}
    if path.is_file():
        try:
            data = json.loads(path.read_text(encoding="utf-8")) or {}
        except Exception:
            data = {}
    return {k: str(v) for k, v in data.items() if isinstance(v, (str, int, float))}


class SingError(RuntimeError):
    pass


def _run(cmd: list[str], cwd: str | None = None, timeout: int = 900) -> subprocess.CompletedProcess:
    p = subprocess.run(
        cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        timeout=timeout,
    )
    if p.returncode != 0:
        tail = (p.stderr or p.stdout or "").strip().splitlines()[-6:]
        raise SingError(f"命令失败（{os.path.basename(cmd[0])}）：" + " / ".join(tail))
    return p


def search_song(title: str, limit: int = 5) -> list[dict]:
    r = requests.post(
        "http://music.163.com/api/search/get/web",
        data={"s": title, "type": 1, "offset": 0, "total": "true", "limit": limit},
        headers=UA,
        timeout=20,
    )
    songs = ((r.json() or {}).get("result") or {}).get("songs") or []
    out = []
    for s in songs:
        out.append(
            {
                "id": s.get("id"),
                "name": s.get("name"),
                "artists": "/".join(a.get("name", "") for a in s.get("artists", [])),
                "duration": s.get("duration") or 0,
                "fee": s.get("fee", 0),
            }
        )
    return out


def song_url(song_id: int | str) -> str:
    """拿音频直链。多个源依次试，任一返回真音频就收工。"""
    apis = [
        f"https://api.injahow.cn/meting/?type=url&id={song_id}",
        f"https://api.injahow.cn/meting/?server=netease&type=url&id={song_id}",
        f"https://music.163.com/song/media/outer/url?id={song_id}.mp3",
    ]
    errors: list[str] = []
    for api in apis:
        try:
            r = requests.get(api, headers=UA, timeout=25, allow_redirects=True)
        except Exception as e:
            errors.append(f"{api.split('/')[2]}: {type(e).__name__}")
            continue
        if r.status_code != 200 or not r.content:
            errors.append(f"{api.split('/')[2]}: HTTP {r.status_code}")
            continue
        ctype = (r.headers.get("Content-Type") or "").lower()
        head = r.content[:12]
        is_audio = (
            "audio" in ctype
            or head[:3] == b"ID3"
            or head[:2] in (b"\xff\xfb", b"\xff\xf3", b"\xff\xf2")
            or b"ftyp" in head
            or head[:4] == b"fLaC"
            or head[:4] == b"OggS"
        )
        if is_audio:
            return r.url
        errors.append(f"{api.split('/')[2]}: 非音频 {ctype or head[:8]!r}")
    raise SingError("拿不到音频直链（" + "；".join(errors) + "）——可能是版权限制或该源没音源")

def download(url: str, dst: Path) -> Path:
    with requests.get(url, headers=UA, timeout=120, stream=True) as r:
        r.raise_for_status()
        with open(dst, "wb") as f:
            for chunk in r.iter_content(1 << 16):
                f.write(chunk)
    if dst.stat().st_size < 200 * 1024:
        raise SingError("下载下来的音频太小，可能不是完整歌曲")
    return dst


def duration_of(path: Path, ffprobe: str) -> float:
    p = _run([ffprobe, "-v", "error", "-show_entries", "format=duration", "-of", "default=nw=1:nk=1", str(path)], timeout=60)
    try:
        return float(p.stdout.strip())
    except ValueError:
        return 0.0


def cut(src: Path, dst: Path, start: int, seconds: int, ffmpeg: str) -> Path:
    _run([ffmpeg, "-y", "-ss", str(start), "-t", str(seconds), "-i", str(src), "-ar", "44100", "-ac", "1", str(dst)])
    return dst


def separate(wav: Path, out_dir: Path, python: str, ffmpeg: str) -> tuple[Path, Path]:
    _run([python, "-m", "demucs", "--two-stems=vocals", "-n", "htdemucs", "-o", str(out_dir), str(wav)], timeout=900)
    stem_dir = out_dir / "htdemucs" / wav.stem
    vocals, inst = stem_dir / "vocals.wav", stem_dir / "no_vocals.wav"
    if not vocals.is_file() or not inst.is_file():
        raise SingError("人声分离没有产出 vocals/no_vocals")
    mono = out_dir / "vocals_mono.wav"
    _run([ffmpeg, "-y", "-i", str(vocals), "-ar", "44100", "-ac", "1", str(mono)])
    return mono, inst


def convert(vocals_mono: Path, ref: Path, out_dir: Path, cfg: dict) -> Path:
    repo = Path(cfg["svc_repo"])
    env = dict(os.environ)
    env["HF_ENDPOINT"] = "https://hf-mirror.com"
    cmd = [
        cfg["svc_python"], "-X", "utf8", "inference.py",
        "--source", str(vocals_mono),
        "--target", str(ref),
        "--output", str(out_dir),
        "--f0-condition", "True",
        "--diffusion-steps", str(cfg["diffusion_steps"]),
        "--inference-cfg-rate", str(cfg["cfg_rate"]),
        "--semi-tone-shift", str(int(cfg.get("semi_tone_shift", 0) or 0)),
    ]
    p = subprocess.run(cmd, cwd=str(repo), capture_output=True, text=True, encoding="utf-8", errors="replace", env=env, timeout=1800)
    made = sorted(out_dir.glob("vc_*.wav"), key=lambda x: x.stat().st_mtime, reverse=True)
    if not made:
        tail = (p.stderr or p.stdout or "").strip().splitlines()[-6:]
        raise SingError("转换失败：" + " / ".join(tail))
    return made[0]


def mix(vocal: Path, inst: Path, out: Path, ffmpeg: str) -> Path:
    # 人声增强：高通去低频闷响 + 3kHz 提清晰度 + 压缩稳住动态 + 提音量；
    # 伴奏压下去当底；amix 关掉归一化（默认会把人声和伴奏都砍一半）。
    _run([
        ffmpeg, "-y", "-i", str(vocal), "-i", str(inst),
        "-filter_complex",
        "[0:a]aformat=channel_layouts=stereo,"
        "highpass=f=90,"
        "equalizer=f=3000:t=q:w=1.2:g=2,"
        "equalizer=f=6500:t=q:w=1.5:g=-2,"
        "equalizer=f=180:t=q:w=1.0:g=-1.5,"
        "acompressor=threshold=-20dB:ratio=2:attack=10:release=200,"
        "volume=1.28[v];"
        "[1:a]volume=0.55[b];"
        "[v][b]amix=inputs=2:duration=first:dropout_transition=0:normalize=0,"
        "alimiter=limit=0.89[out]",
        "-map", "[out]", "-b:a", "192k", str(out),
    ])
    return out


def split_audio(src: Path, chunk_seconds: int, ffmpeg: str, out_dir: Path) -> list[Path]:
    """把长音频均分成若干段，每段不超过 chunk_seconds（QQ 语音 60 秒硬上限）。

    均分而不是「58 + 2 秒」，避免最后剩一条很短的尾巴。
    """
    total = duration_of(src, str(Path(ffmpeg).with_name("ffprobe.exe")))
    if total <= 0:
        return [src]
    if total <= chunk_seconds:
        return [src]
    n = int(total // chunk_seconds) + (1 if total % chunk_seconds else 0)
    seg = total / n + 0.05  # 留一点余量，避免边界那帧被切到下一段
    out_dir.mkdir(parents=True, exist_ok=True)
    pattern = str(out_dir / "part_%02d.mp3")
    for old in out_dir.glob("part_*.mp3"):
        old.unlink(missing_ok=True)
    _run([
        ffmpeg, "-y", "-i", str(src),
        "-f", "segment", "-segment_time", f"{seg:.2f}", "-reset_timestamps", "1",
        "-c", "copy", pattern,
    ])
    parts = sorted(out_dir.glob("part_*.mp3"))
    return parts or [src]

def cover_url(song_id: int | str, dst: Path, direct: str = "") -> Path | None:
    """下载歌曲封面（先试传进来的直链，再从 song/detail 拿 picUrl）。"""
    urls: list[str] = []
    if direct:
        urls.append(direct)
    try:
        r = requests.get(
            f"https://music.163.com/api/song/detail?ids=[{song_id}]",
            headers=UA, timeout=20,
        )
        js = r.json()
        pic = ((js.get("songs") or [{}])[0].get("album") or {}).get("picUrl") or ""
        if pic:
            urls.append(pic)
    except Exception:
        pass

    for url in urls:
        try:
            img = requests.get(url, headers=UA, timeout=30)
            if img.status_code == 200 and len(img.content) > 2048:
                dst.write_bytes(img.content)
                return dst
        except Exception:
            continue
    return None


def make_video(audio: Path, cover: Path | None, out: Path, ffmpeg: str) -> Path:
    """音频 + 一张封面 → mp4。QQ 里发出来是视频，点开就播，时长不受 60 秒限制。"""
    if cover and cover.is_file():
        cmd = [
            ffmpeg, "-y", "-loop", "1", "-i", str(cover), "-i", str(audio),
            "-c:v", "libx264", "-tune", "stillimage", "-vf", "scale=720:-2",
            "-c:a", "aac", "-b:a", "192k", "-pix_fmt", "yuv420p", "-shortest", str(out),
        ]
    else:
        cmd = [
            ffmpeg, "-y", "-f", "lavfi", "-i",
            f"color=c=0x2b6cb0:s=720x720:d={max(1, int(duration_of(audio, str(Path(ffmpeg).with_name('ffprobe.exe')))))}",
            "-i", str(audio),
            "-c:v", "libx264", "-tune", "stillimage",
            "-c:a", "aac", "-b:a", "192k", "-pix_fmt", "yuv420p", "-shortest", str(out),
        ]
    _run(cmd, timeout=600)
    return out


BILI_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    "Referer": "https://www.bilibili.com/",
}


def _bili_session(cookie: dict | None = None) -> requests.Session:
    s = requests.Session()
    s.headers.update(BILI_HEADERS)
    if cookie:
        s.cookies.update(cookie)
    try:
        s.get("https://www.bilibili.com/", timeout=15)  # 拿 buvid3，缺了容易被 412
    except Exception:
        pass
    return s


def _bili_duration_seconds(value) -> int:
    """B 站的 duration 是 "3:28" 这种字符串，也可能是数字。"""
    if isinstance(value, (int, float)):
        return int(value)
    text = str(value or "").strip()
    if not text:
        return 0
    parts = text.split(":")
    try:
        total = 0
        for part in parts:
            total = total * 60 + int(part)
        return total
    except ValueError:
        return 0


def bili_search(keyword: str, limit: int = 10, session: requests.Session | None = None, cookie: dict | None = None) -> list[dict]:
    """B 站视频搜索。标题里通常带【洛天依】这种标签，正好拿来认歌手。"""
    import time as _time

    s = session or _bili_session(cookie)
    js = {}
    for attempt in range(2):
        try:
            r = s.get(
                "https://api.bilibili.com/x/web-interface/search/type",
                params={"search_type": "video", "keyword": keyword, "page": 1},
                timeout=20,
            )
            js = r.json()
            if js.get("code") == 0:
                break
        except Exception:
            js = {}
        _time.sleep(1.5 + attempt)
    if js.get("code") != 0:
        return []
    out = []
    for v in ((js.get("data") or {}).get("result") or [])[:limit]:
        title = re.sub(r"<[^>]+>", "", v.get("title") or "")
        out.append(
            {
                "id": v.get("bvid"),
                "name": title,
                "artists": v.get("author") or "",
                "duration": _bili_duration_seconds(v.get("duration")) * 1000,
                "cover": v.get("pic") or "",
            }
        )
    return out


def bili_audio(bvid: str, out: Path, ffmpeg: str, cookie: dict | None = None) -> Path:
    """取 B 站视频的音轨，转成 mp3。"""
    s = _bili_session(cookie)
    js = s.get("https://api.bilibili.com/x/player/pagelist", params={"bvid": bvid}, timeout=20).json()
    if js.get("code") != 0 or not js.get("data"):
        raise SingError(f"B 站取分 P 失败：{js.get('message')}")
    cid = js["data"][0].get("cid")
    js2 = s.get(
        "https://api.bilibili.com/x/player/playurl",
        params={"bvid": bvid, "cid": cid, "fnval": 16, "fourk": 1, "fnver": 0},
        timeout=20,
    ).json()
    dash = ((js2.get("data") or {}).get("dash") or {})
    audios = dash.get("audio") or []
    if not audios:
        raise SingError("B 站这个视频没有可用音轨（可能是直播回放或会员专享）")
    audios.sort(key=lambda a: a.get("bandwidth") or 0, reverse=True)
    url = audios[0].get("baseUrl") or audios[0].get("base_url")
    raw = out.with_suffix(".m4a")
    with s.get(url, headers=BILI_HEADERS, timeout=120, stream=True) as r:
        r.raise_for_status()
        with open(raw, "wb") as f:
            for chunk in r.iter_content(1 << 16):
                f.write(chunk)
    if raw.stat().st_size < 100 * 1024:
        raise SingError("B 站音轨下载不完整")
    _run([ffmpeg, "-y", "-i", str(raw), "-ar", "44100", "-ac", "2", str(out)])
    return out


def _split_query(title: str, songs: list[dict]) -> tuple[str, str]:
    """把「思恋 洛天依版」拆成（歌名=思恋，歌手提示=洛天依）。"""
    q = title.strip()
    song, hint = q, ""
    for length in range(len(q), 1, -1):
        sub = q[:length].strip()
        if any((s["name"] or "").startswith(sub) for s in songs):
            song, hint = sub, q[length:]
            break
    hint = hint.strip().strip("-—_ ").strip()
    for suffix in ("版本", "版", "翻唱", "cover", "Cover"):
        if hint.endswith(suffix):
            hint = hint[: -len(suffix)].strip()
    return song, hint


def _hint_score(hint: str, song: dict) -> float:
    """歌手提示与候选的匹配分：完全命中 3 分，模糊命中 1~2 分，不沾边 0 分。"""
    import difflib

    if not hint:
        return 0.0
    text = ((song.get("artists") or "") + (song.get("name") or "")).replace(" ", "")
    if hint in text:
        return 3.0
    best = 0.0
    for part in [p for p in re.split(r"[、/&,，]", text) if p]:
        ratio = difflib.SequenceMatcher(None, hint, part).ratio()
        if ratio >= 0.55:
            best = max(best, 1.0 + ratio)
    ratio = difflib.SequenceMatcher(None, hint, text).ratio()
    if ratio >= 0.55:
        best = max(best, 1.0 + ratio)
    return best


def _try_bili(title: str, song_key: str, hint: str, work: Path, cfg: dict) -> tuple[dict, Path]:
    """在 B 站按「歌名 歌手」搜，标题必须明确命中歌名才认。"""
    query = f"{song_key} {hint}".strip() if hint else song_key
    songs = bili_search(query, cookie=cfg.get("bili_cookie") or None)
    if not songs:
        raise SingError(f"B 站也搜不到「{query}」")

    key = song_key.replace(" ", "")
    scored = []
    for s in songs:
        text = (s["name"] or "").replace(" ", "")
        if key not in text:
            continue
        # 标题里的位置越靠前越可信；套着《》的基本就是这首歌
        if f"《{key}》" in text or f"《{song_key}》" in (s["name"] or ""):
            quality = 3
        elif key in text[:20]:
            quality = 2
        else:
            quality = 1
        scored.append((quality, _hint_score(hint, s), s["duration"] or 0, s))

    if not scored:
        raise SingError(f"B 站搜到 {len(songs)} 个视频，标题里都没有「{song_key}」")
    scored.sort(key=lambda x: (x[0], x[1], x[2]), reverse=True)
    best = scored[0]
    if best[0] < 2:
        raise SingError(f"B 站找到的「{best[3]['name'][:24]}」只是标题里提到「{song_key}」，不是这首歌")
    song = best[3]
    audio = bili_audio(song["id"], work / "bili_source.mp3", cfg["ffmpeg"], cfg.get("bili_cookie") or None)
    return song, audio


def _probe_length(url: str) -> float:
    """只发 HEAD/Range 估一下这个直链能拿到多长（秒）。失败返回 0。"""
    try:
        r = requests.head(url, headers=UA, timeout=12, allow_redirects=True)
        size = int(r.headers.get("Content-Length") or 0)
        if not size:
            r = requests.get(url, headers={**UA, "Range": "bytes=0-1"}, timeout=12)
            cr = r.headers.get("Content-Range") or ""
            if "/" in cr:
                size = int(cr.split("/")[-1] or 0)
        # 网易云直链一般是 128k/320k 混合，按 128k 估算偏保守
        return (size * 8) / 128000 if size else 0.0
    except Exception:
        return 0.0


def probe_songs(songs: list[dict], limit: int, cfg: dict) -> list[dict]:
    """给候选补上「能不能听全」和真实时长（并发探测，别一条条等）。"""
    from concurrent.futures import ThreadPoolExecutor

    def _one(song: dict) -> dict:
        item = dict(song)
        if item.get("source") == "bili":
            item["actual_seconds"] = (item.get("duration") or 0) / 1000.0
            item["trial"] = False
            return item
        declared = (item.get("duration") or 0) / 1000.0
        est = 0.0
        try:
            est = _probe_length(song_url(item["id"]))
        except Exception:
            est = 0.0
        if est and declared and declared > 90 and est < declared * 0.6:
            item["trial"] = True
            item["actual_seconds"] = est
        else:
            item["trial"] = False
            item["actual_seconds"] = declared
        return item

    picked = songs[:limit]
    with ThreadPoolExecutor(max_workers=min(6, max(1, len(picked)))) as pool:
        return list(pool.map(_one, picked))

def _clean_video_title(text: str) -> str:
    """B 站标题清理：反转义、去【】标签与副标题、截断。"""
    import html as _html

    s = _html.unescape(text or "")
    s = s.split("|")[0]                      # 去「|今天的我…」这种副标题
    s = re.sub(r"【[^】]{0,20}】", " ", s)
    s = re.sub(r"\[[^\]]{0,20}\]", " ", s)
    s = re.sub(r"[（(][^）)]{0,16}[）)]", " ", s)
    s = s.replace("《", "").replace("》", "").replace("「", "").replace("」", "")
    s = re.sub(r"\s+", " ", s).strip().strip("-—_|· ")
    if len(s) > 18:
        s = s[:18] + "…"
    return s or _html.unescape(text or "")

def list_versions(title: str, limit: int = 6, cfg: dict | None = None, source: str = "all") -> tuple[str, str, list[dict]]:
    """列出候选版本。source: all / netease / bili，每项带 source + id。"""
    cfg = cfg or {}
    songs = search_song(title, limit=15)
    song_key, hint = (_split_query(title, songs) if songs else (title, ""))

    out: list[dict] = []
    seen: set[tuple] = set()

    if source in ("all", "netease"):
        for s in songs:
            name = s["name"] or ""
            if song_key and not (name.startswith(song_key) or song_key in name):
                continue
            key = (name, s.get("artists") or "")
            if key in seen:
                continue
            seen.add(key)
            item = dict(s)
            item["source"] = "netease"
            out.append(item)
            if len(out) >= limit:
                break
        if hint:
            out.sort(key=lambda s: _hint_score(hint, s), reverse=True)

    if source in ("all", "bili"):
        query = f"{song_key} {hint}".strip() if hint else song_key
        try:
            videos = bili_search(query, limit=12, cookie=cfg.get("bili_cookie") or None)
        except Exception:
            videos = []
        added = 0
        for v in videos:
            secs = (v.get("duration") or 0) / 1000.0
            if secs < 30 or secs > 720:      # 太短的片段、太长的合集都不算歌
                continue
            raw_title = v["name"] or ""
            text = raw_title.replace(" ", "")
            if song_key.replace(" ", "") not in text:
                continue
            if not (f"《{song_key}》" in raw_title or song_key in text[:20]):
                continue
            item = dict(v)
            item["name"] = _clean_video_title(raw_title)
            key = (item["name"], v.get("artists") or "")
            if key in seen:
                continue
            seen.add(key)
            item["source"] = "bili"
            out.append(item)
            added += 1
            if added >= limit:
                break

    out = out[:limit]
    if cfg.get("probe_versions", True) and out:
        out = probe_songs(out, limit, cfg)
    return song_key, hint, out


def _pick_source(songs: list[dict], title: str, work: Path, cfg: dict) -> tuple[dict, Path]:
    """网易云优先；歌手搜不到或全是试听源时，按开关回落到 B 站。"""
    problems: list[str] = []
    try:
        return _pick_netease(songs, title, work, cfg, problems)
    except SingError as e:
        problems.append(str(e))

    if cfg.get("enable_bilibili", True):
        try:
            song_key, hint = _split_query(title, songs)
            song, audio = _try_bili(title, song_key, hint, work, cfg)
            return song, audio
        except SingError as e:
            problems.append(str(e))

    raise SingError("；".join(problems))


def _pick_netease(songs: list[dict], title: str, work: Path, cfg: dict, problems: list[str]) -> tuple[dict, Path]:
    """网易云：歌名先定，再用歌手提示做完全/模糊匹配，试听源（VIP 30 秒）自动跳过。"""
    song_key, hint = _split_query(title, songs)

    picked = songs
    if song_key:
        same_name = [s for s in songs if (s["name"] or "").startswith(song_key)]
        if same_name:
            picked = same_name

    scored = [(_hint_score(hint, s), s) for s in picked]
    if hint:
        fuzzy = [pair for pair in scored if pair[0] > 0]
        if not fuzzy:
            titles = "、".join(f"{s['name']}-{s['artists']}" for s in songs[:6])
            raise SingError(f"没搜到「{hint}」的版本（模糊匹配也没有）。网易云搜到的是：{titles}")
        scored = fuzzy

    def _rank(pair: tuple) -> tuple:
        hint_score, s = pair
        name = (s["name"] or "").replace(" ", "")
        exact = 1 if name == song_key.replace(" ", "") else 0
        return (hint_score, exact, s["duration"] or 0)

    ranked = [s for _, s in sorted(scored, key=_rank, reverse=True)[:6]]
    for i, song in enumerate(ranked):
        declared = (song["duration"] or 0) / 1000.0
        try:
            url = song_url(song["id"])
            src = download(url, work / f"source_{i}.mp3")
        except Exception as e:
            problems.append(f"{song['name']}-{song['artists']}: {e}")
            continue
        got = duration_of(src, cfg["ffprobe"])
        if declared > 90 and got < max(60.0, declared * 0.6):
            problems.append(f"{song['name']}-{song['artists']}: 只拿到 {got:.0f}s / 标称 {declared:.0f}s（试听源）")
            continue
        return song, src
    raise SingError("网易云这些版本都拿不到完整音源：" + "；".join(problems[-3:]))


def fetch_original(title: str, cfg: dict, workdir: Path | None = None, preferred: dict | None = None) -> dict:
    """点歌用：只把原曲下下来，不做任何转换。"""
    c = dict(cfg or {})
    root = Path(c["work_root"])
    root.mkdir(parents=True, exist_ok=True)
    work = workdir or Path(tempfile.mkdtemp(dir=str(root), prefix="play_"))
    work.mkdir(parents=True, exist_ok=True)

    if preferred:
        song = {
            "id": preferred.get("id"),
            "name": preferred.get("name") or title,
            "artists": preferred.get("artists") or "",
            "duration": preferred.get("duration") or 0,
            "cover": preferred.get("cover") or "",
        }
        if preferred.get("source") == "bili":
            src = bili_audio(song["id"], work / "bili_source.mp3", c["ffmpeg"], c.get("bili_cookie") or None)
        else:
            src = download(song_url(song["id"]), work / "source.mp3")
    else:
        songs = search_song(title)
        if not songs:
            raise SingError(f"没搜到「{title}」")
        if c.get("force_source") == "bili":
            _key, _hint = _split_query(title, songs)
            song, src = _try_bili(title, _key, _hint, work, c)
        else:
            song, src = _pick_source(songs, title, work, c)

    cover = cover_url(song["id"], work / "cover.jpg", direct=song.get("cover", ""))
    return {
        "path": str(src),
        "name": song["name"],
        "artists": song["artists"],
        "cover": str(cover) if cover else "",
        "seconds": duration_of(src, c["ffprobe"]),
    }


def make_cover(title: str, cfg: dict | None = None, workdir: Path | None = None) -> dict:
    """跑完整条流水线，返回 {path, vocals_only, name, artists, seconds, cover}。"""
    c = dict(cfg or {})
    missing = [k for k in ("svc_python", "svc_repo", "ffmpeg", "ffprobe", "ref_audio", "work_root") if not c.get(k)]
    if missing:
        raise SingError("缺少运行配置：" + "、".join(missing) + "（先跑 install.ps1 生成 runtime.json）")
    c.setdefault("cfg_rate", 0.7)
    if not Path(c["ref_audio"]).is_file():
        raise SingError(f"参考音色不存在：{c['ref_audio']}")

    pref = c.get("preferred") or None
    songs = [] if pref else search_song(title)
    if not pref and not songs:
        raise SingError(f"没搜到「{title}」")

    root = Path(c["work_root"])
    root.mkdir(parents=True, exist_ok=True)
    work = workdir or Path(tempfile.mkdtemp(dir=str(root), prefix="sing_"))
    work.mkdir(parents=True, exist_ok=True)

    if pref:
        song = {
            "id": pref.get("id"),
            "name": pref.get("name") or title,
            "artists": pref.get("artists") or "",
            "duration": pref.get("duration") or 0,
            "cover": pref.get("cover") or "",
        }
        if pref.get("source") == "bili":
            src = bili_audio(song["id"], work / "bili_source.mp3", c["ffmpeg"], c.get("bili_cookie") or None)
        else:
            src = download(song_url(song["id"]), work / "source.mp3")
    else:
        if c.get("force_source") == "bili":
            _key, _hint = _split_query(title, songs) if songs else (title, "")
            song, src = _try_bili(title, _key, _hint, work, c)
        else:
            song, src = _pick_source(songs, title, work, c)
    declared = (song["duration"] or 0) / 1000.0
    if declared and declared < (int(c.get("clip_start", 0)) + int(c.get("clip_seconds", 420))):
        c["clip_start"] = 0  # 歌不够长就从头唱

    clip = cut(src, work / "clip.wav", int(int(c.get("clip_start", 0))), int(int(c.get("clip_seconds", 420))), c["ffmpeg"])
    vocals_mono, inst = separate(clip, work, c["svc_python"], c["ffmpeg"])
    vc = convert(vocals_mono, Path(c["ref_audio"]), work, c)
    out = mix(vc, inst, work / "final.mp3", c["ffmpeg"])
    cover = cover_url(song["id"], work / "cover.jpg", direct=song.get("cover", ""))
    return {
        "path": str(out),
        "vocals_only": str(vc),
        "cover": str(cover) if cover else "",
        "name": song["name"],
        "artists": song["artists"],
        "seconds": duration_of(out, c["ffprobe"]),
    }
