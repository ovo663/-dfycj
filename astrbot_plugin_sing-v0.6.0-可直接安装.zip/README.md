# astrbot_plugin_sing

给 [AstrBot](https://github.com/AstrBotDevs/AstrBot) 用的「唱歌」插件：在群里说一句「唱 歌名」，它去搜歌、做人声分离、用 **Seed-VC 零样本音色转换**换成指定音色，再按你选的方式发回来。

- **点歌**：`点歌 歌名` —— 只放原曲，不转换
- **翻唱**：`唱 歌名` —— 换成她的声音唱
- 音源：**网易云优先，B 站兜底**（可选 B 站扫码登录）
- 发送方式：**多条语音 / 一条视频 / mp3 文件**，可各自开关
- 版本选择：同名多版本时列出来让你挑，标明 `［可听全］` / `［仅试听］` 和真实时长

## 效果与原理

```
唱 歌名
  → 选源（网易云 / B站）
  → 选版本（可听全 / 仅试听 + 时长）
  → 选发送方式
  → 下载 → 截取 → demucs 人声分离 → Seed-VC 换音色 → 混音（人声增强）→ 发送
```

一首 4 分钟的歌，RTX 5080 上全程约 60–90 秒。

## 依赖（重要）

本插件只是「遥控器」，真正的推理在外部环境里，需要先准备好：

| 组件 | 用途 | 说明 |
|---|---|---|
| Python 环境 | torch + demucs | 建议独立 venv，torch 版本按显卡选（50 系必须 cu128） |
| [Seed-VC](https://github.com/Plachtaa/seed-vc) | 音色转换 | GPL-3.0，需自行下载，权重约 2.3 GB |
| ffmpeg | 转码 / 混音 | PATH 里有，或写绝对路径 |
| 参考音色 | 目标声音 | 10–30 秒干净语音，wav |

安装参考：

```powershell
# 1) 建环境
python -m venv D:\dafeiyu\svc-env
D:\dafeiyu\svc-env\Scripts\python.exe -m pip install -U pip
D:\dafeiyu\svc-env\Scripts\python.exe -m pip install torch torchaudio --index-url https://download.pytorch.org/whl/cu128
D:\dafeiyu\svc-env\Scripts\python.exe -m pip install -i https://mirrors.aliyun.com/pypi/simple/ `
    numpy scipy librosa soundfile munch einops tqdm descript-audio-codec transformers huggingface_hub pyyaml demucs

# 2) 下载 Seed-VC
Invoke-WebRequest "https://codeload.github.com/Plachtaa/seed-vc/zip/refs/heads/main" -OutFile seed-vc.zip
Expand-Archive seed-vc.zip -DestinationPath .
```

**装完要打两个补丁**（不打必报错）：

1. `seed-vc/modules/bigvgan/bigvgan.py` 的 `_from_pretrained` 参数补默认值
   （新版 `huggingface_hub` 会报 `missing 'proxies' and 'resume_download'`）
2. `seed-vc/inference.py` 末尾的 `torchaudio.save(...)` 改成 `soundfile.write(...)`
   （`torchaudio ≥ 2.9` 存盘要 `torchcodec`，而它没有 Windows 轮子）

**不要装 `resemblyzer`** —— 它依赖 `webrtcvc`/`webrtcvad`，Windows 上要 MSVC 编译，而且推理用不到。

首次推理会自动从 HuggingFace 拉权重，国内先设镜像：

```powershell
$env:HF_ENDPOINT = "https://hf-mirror.com"
```

## 安装插件

1. 把本目录放到 `AstrBot/data/plugins/astrbot_plugin_sing/`
2. 复制 `runtime.example.json` 为 `runtime.json`，填上真实路径
3. 准备参考音色，转成 44.1k 单声道：
   `ffmpeg -i 源.wav -ar 44100 -ac 1 her_ref.wav`
4. 重启 AstrBot，日志里应出现 `Loading plugin astrbot_plugin_sing`

## 配置

WebUI → 插件 → 唱歌，或直接改 `data/config/astrbot_plugin_sing_config.json`。

| 键 | 默认 | 说明 |
|---|---|---|
| `enable` | true | 总开关 |
| `play_enabled` | true | 点歌开关 |
| `allow_voice` / `allow_video` / `allow_file` | true | 三种发送方式各自的开关；只开一个就不询问 |
| `owner_uins` | ["你的QQ"] | 谁算主人 |
| `owner_enabled` / `others_enabled` | true | 主人 / 其他人能不能用 |
| `admin_uins` | ["你的QQ"] | 管理员：无视触发词位置、唤醒、开关限制 |
| `trigger_words` | ["唱歌","唱"] | 触发词，只有以它们开头的消息才算点歌 |
| `need_wake` | true | 关掉后触发词直接生效，不用 @ |
| `enable_netease` / `enable_bilibili` | true | 音源开关，两个都开时会询问用哪个 |
| `ask_version` | true | 同名多版本时是否先让你选 |
| `clip_start` / `clip_seconds` | 0 / 420 | 从第几秒开始唱、最多唱多长（7 分钟） |
| `chunk_seconds` | 120 | 单条语音上限；超过会均分成多条 |
| `diffusion_steps` | 60 | Seed-VC 扩散步数，越大越清晰越慢 |
| `cfg_rate` | 0 | 贴合强度，0 = 不做额外引导（高音更松） |
| `semi_tone_shift` | 0 | 半音移调；负值降调可减少高音撕裂，但伴奏不会跟着变调 |

## 指令

| 指令 | 说明 |
|---|---|
| `唱 歌名` | 翻唱 |
| `唱 歌名 歌手版` | 指定歌手，如 `唱 思恋 洛天依版`（支持模糊匹配） |
| `唱 歌名 视频` | 带后缀可跳过发送方式询问 |
| `点歌 歌名` | 只放原曲 |
| `扫码登录` / `刷新状态` / `重新登录` | B 站账号（管理员） |

## B 站登录

`扫码登录` 会发一张二维码，用 B 站 App 扫，Cookie 存在插件目录的 `bili_cookies.json`。

- 登录后音质更稳、少被风控
- **不会**解锁会员音源
- Cookie 约 30 天过期，失效后发 `重新登录`

## 已知限制

- **QQ 语音单条有上限**：实测 120 秒可以正常播，更长未验证；超过 `chunk_seconds` 会均分成多条
- **网易云部分歌曲只给 30 秒试听**：版本列表会标 `［仅试听］`，选别的版本即可
- **B 站搜索结果嘈杂**：做了标题清理、时长过滤（30 秒–12 分钟）、同名去重，但同名不同 UP 仍要靠歌手名区分
- **纯 CPU 也能跑**，但一首 5 分钟的歌要十几分钟

## 许可证

- 本插件代码：MIT
- [Seed-VC](https://github.com/Plachtaa/seed-vc)：**GPL-3.0**。本插件通过子进程调用它，**不打包、不修改其源码**；如果你的分发方式构成衍生作品，请遵循 GPL-3.0
- [demucs](https://github.com/facebookresearch/demucs)：MIT
- ffmpeg：LGPL/GPL，取决于构建

## 目录

```
astrbot_plugin_sing/
  main.py              # AstrBot 插件入口：指令、状态机、发送
  core/pipeline.py     # 搜歌 / 下载 / 分离 / 转换 / 混音
  core/bili_login.py   # B 站扫码登录
  _conf_schema.json    # 配置项定义
  runtime.example.json # 运行环境路径模板（复制成 runtime.json）
  metadata.yaml
```

## 发布（自动打包）

仓库自带 `.github/workflows/release.yml`：推送 `v*` 标签就会自动校验语法、打包插件目录，并把 zip 挂到对应的 Release 上。

```bash
git tag v0.6.0
git push origin v0.6.0
```

包里会自动排除 `runtime.json`、`bili_cookies.json`、`bili_qr.png`、`__pycache__`。
也可以在 Actions 页面手动触发（`workflow_dispatch`）。