# -*- coding: utf-8 -*-
"""B 站扫码登录：拿二维码 → 轮询 → 存 Cookie。

只做三件事，纯 HTTP，不经过任何大模型。
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import requests

UA = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/120.0 Safari/537.36",
    "Referer": "https://www.bilibili.com/",
}

GENERATE = "https://passport.bilibili.com/x/passport-login/web/qrcode/generate"
POLL = "https://passport.bilibili.com/x/passport-login/web/qrcode/poll"
COOKIE_FILE = "bili_cookies.json"


def make_qr(png_path: Path) -> tuple[str, Path]:
    """申请登录二维码，返回 (qrcode_key, 本地 png 路径)。"""
    import qrcode

    r = requests.get(GENERATE, headers=UA, timeout=20)
    js = r.json()
    if js.get("code") != 0:
        raise RuntimeError(f"申请二维码失败：{js.get('message')}")
    data = js["data"]
    key, url = data["qrcode_key"], data["url"]

    img = qrcode.make(url)
    img.save(str(png_path))
    return key, png_path


def poll_once(key: str) -> dict:
    """查一次扫码状态：waiting / scanned / expired / ok。"""
    r = requests.get(POLL, params={"qrcode_key": key}, headers=UA, timeout=20)
    js = r.json()
    code = (js.get("data") or {}).get("code")
    mapping = {86101: "waiting", 86090: "scanned", 86038: "expired", 0: "ok"}
    status = mapping.get(code, f"unknown:{code}")
    cookies = {}
    if status == "ok":
        for item in r.cookies:
            cookies[item.name] = item.value
        # 有些情况 Cookie 在 data.url 里
        url = (js.get("data") or {}).get("url") or ""
        if url and "?" in url:
            from urllib.parse import parse_qs

            for k, v in parse_qs(url.split("?", 1)[1]).items():
                if k in ("SESSDATA", "bili_jct", "DedeUserID", "DedeUserID__ckMd5", "sid"):
                    cookies[k] = v[0]
    return {"status": status, "cookies": cookies, "raw": js}


def save_cookies(plugin_dir: Path, cookies: dict) -> Path:
    path = Path(plugin_dir) / COOKIE_FILE
    payload = {"cookies": cookies, "saved_at": int(time.time())}
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def load_cookies(plugin_dir: Path) -> dict:
    path = Path(plugin_dir) / COOKIE_FILE
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8")) or {}
        cookies = data.get("cookies") or {}
        return cookies if isinstance(cookies, dict) else {}
    except Exception:
        return {}
